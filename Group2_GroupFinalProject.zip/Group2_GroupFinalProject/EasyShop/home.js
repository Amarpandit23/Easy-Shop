"use strict";
$(document).ready(function () {

    // enable slider
    $('.bxslider').bxSlider({
        infiniteLoop: false,
        hideControlOnEnd: true,
        
      });
});



