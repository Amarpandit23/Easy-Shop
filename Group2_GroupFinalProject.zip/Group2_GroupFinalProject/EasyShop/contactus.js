"use strict";                          
$(document).ready( function() {
    $("#name").focus();

     

    $("#form").submit( evt => {
        
        let valid = true;
        const name=$("#name").val().trim();
        
        $("#submitbtn").click(function(){
            Swal.fire({
                title: "Successfully saved!",
                text: "Thanks for the feedback, we will contact you soon",
                icon: "success",
                timer: 4000
              });
              
         })
        if(name===""){
            $("#name").next().text("Please enter your name");
            valid = false;
        }
        else {
            $("#name").next().text("");
        }

        const email=$("#emailaddress").val().trim();
        const emailpattern = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|.(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if(email===""){
            $("#emailaddress").next().text("Please enter your email id");
            valid = false;
        }
        else if(!emailpattern.test(email)){
            $("#emailaddress").next().text("Please enter a valid email id");
            valid = false;
        }
        else {
            $("#emailaddress").next().text("");
        }
        $("#emailaddress").val(email);

        const phone=$("#phone").val().trim();
        const phonepattern=/^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
        ;
        if(phone===""){
            $("#phone").next().text("Please enter your phone number");
            valid = false;
        }
        else if(!phonepattern.test(phone)){
            $("#phone").next().text("Please enter a valid phone number");
            valid = false;
        }
        else {
            $("#phone").next().text("");
        }
        $("#phone").val(phone);

        const message=$("#message").val().trim();
        if(message===""){
            $("#message").next().text("Please enter your message");
            valid = false;
        }
        else {
            $("#message").next().text("");
        }
        $("#message").val(message);
        evt.preventDefault();
        $("#form")[0].reset();
    });
}
);