"use strict";
const proImages = document.querySelectorAll('.product1');


const selImg = document.querySelector('.selectedimg');


proImages.forEach(proImage => {
    
    proImage.addEventListener('mouseover', function() {
        
        selImg.src = this.src;
    });
});